package com.example.myrezt;



import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

@RequestMapping(path="/RestApi",produces="application/json")
@CrossOrigin(origins="*")
public class ReztController {
	
	@GetMapping("/getData")	public EmployeeData get() {
		EmployeeData z=new EmployeeData();
		z.setMsg("Hello all");
		z.setEmployeeName("George");
		return z;
		
	}
	@PostMapping
	public ResponseEntity<EmployeeData> 
	post (@RequestBody EmployeeData z){
   HttpHeaders header=new HttpHeaders();	
   return new ResponseEntity<>(z,header,HttpStatus.CREATED);
   
	}
	

}
