package com.example.myrezt;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class ReztTemplate {
	RestTemplate rest=new RestTemplate();
	
	public EmployeeData getEmployeeData() {
		return rest.getForObject(
				"http://localhost:8081/RestApi/getData",
				EmployeeData.class);
		
	}
	
	public ResponseEntity<EmployeeData> post(EmployeeData user){
		return rest.postForEntity(
				"http://localhost:8081/RestApi",
				user,EmployeeData.class,"");
	}


	

}
