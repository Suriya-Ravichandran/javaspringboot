package com.example.myrezt;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/Api")
public class ConsumeController {
	@GetMapping
	public String get(Model model) {
		ReztTemplate rt=new ReztTemplate();
		model.addAttribute("user", rt.getEmployeeData());
		model.addAttribute("model",new EmployeeData());
		return "GetData";
		
		
	}
	@PostMapping
	public String post(@ModelAttribute("model")
	EmployeeData user,Model model) {
		ReztTemplate rt=new ReztTemplate();
		ResponseEntity<EmployeeData> response=rt.post(user);
		model.addAttribute("user", response.getBody());
		model.addAttribute("header",
				response.getHeaders()+" "+response.getStatusCode());
		return "GetData";
		
		
	}

}
