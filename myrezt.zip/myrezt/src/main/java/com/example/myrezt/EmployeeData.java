package com.example.myrezt;

import lombok.Data;

@Data
public class EmployeeData {
	public String msg;
	public String employeeName;
	
	public String getMsg() {
		return msg;
		
	}
	public void setMsg(String msg) {
		this.msg=msg;
	}
	
	public String getEmployeeName() {
		return employeeName;
		
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName=employeeName;
	}
	
	

}
