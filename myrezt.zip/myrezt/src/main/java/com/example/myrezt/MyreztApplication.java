package com.example.myrezt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyreztApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyreztApplication.class, args);
	}

}
