package com.example.myrezt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyreztApplicationTests {

	@Test
	void contextLoads() {
	}

}
