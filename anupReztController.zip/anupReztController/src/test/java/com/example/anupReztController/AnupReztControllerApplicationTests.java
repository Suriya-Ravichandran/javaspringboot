package com.example.anupReztController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnupReztControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
