package com.example.anupReztController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnupReztControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnupReztControllerApplication.class, args);
	}

}
